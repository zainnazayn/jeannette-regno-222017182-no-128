/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package library.system;


public class LIBRARYSYSTEM {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         LOGIN loginFrame = new LOGIN(); 
        loginFrame.setVisible(true);
        loginFrame.pack ();
        loginFrame.setLocationRelativeTo(null);
        

    }
    
}
